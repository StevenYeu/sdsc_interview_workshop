pub mod trie;

fn main() {
    println!("Hello, world!");
}
